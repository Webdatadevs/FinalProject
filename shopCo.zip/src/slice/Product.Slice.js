import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    isLoading: true,
    products: [],
    toSortedProducts: [],
    theMostExpensive: [],
};
export const productSlice = createSlice({
    name: "product",
    initialState,
    reducers: {
        isLoadingProduct(state) {
            state.isLoading = true;
        },
        setProducts(state, action) {
            state.products = action.payload;
            state.isLoading = false;
        },
        setSortProducts(state, action) {
            state.toSortedProducts = action.payload;
        },
        setTheMostExpensive(state, action) {
            state.theMostExpensive = action.payload;
        },
    },
});

export const {
    setProducts,
    isLoadingProduct,
    setSortProducts,
    setTheMostExpensive,
} = productSlice.actions;

export default productSlice.reducer;
