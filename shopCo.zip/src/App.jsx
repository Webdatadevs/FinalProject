import React from "react";
import Header from "./components/Header/Header";
import Banner from "./components/Header/Banner";
import Content from "./components/Main/Content";

const App = () => {

    return (
        <>
            <Header />
            <Banner />
            <Content />
        </>
    );
};

export default App;
