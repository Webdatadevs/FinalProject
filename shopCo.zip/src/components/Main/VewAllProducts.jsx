import { AiOutlineHeart } from "react-icons/ai";
import {
    Box,
    Button,
    Card,
    CardBody,
    CardFooter,
    CardHeader,
    Heading,
    IconButton,
    Img,
    Text,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";


const VewAllProducts = () => {
    const { products } = useSelector((state) => state.products);
    const [click, setClick] = useState(false);
    return (
        <>
            <Box
                width={"90%"}
                marginX={"auto"}
                display={"flex"}
                marginTop={"40px"}
                flexDirection={"column"}
                justifyContent={"center"}
                alignItems={"center"}
            >
                <Button
                    display={"flex"}
                    fontSize={"24px"}
                    textColor={"#222"}
                    background={"#F0EEED"}
                    _hover={{ background: "#F0EEED" }}
                    _active={{ transform: "scale(0.8)" }}
                    marginTop={"20px"}
                    marginBottom={"10px"}
                    padding={"15px"}
                    onClick={() => setClick((value) => !value)}
                >
                    Vew All goods
                </Button>
                <Heading
                    display={click ? "block" : "none"}
                    textAlign={"center"}
                    marginTop={"25px"}
                >
                    All goods
                </Heading>
                <Box
                    display={click ? "grid" : "none"}
                    // display={'flex'}
                    width={"100%"}
                    // overflowX={'auto'}
                    gridTemplateColumns={"repeat(auto-fit, minmax(200px, 1fr))"}
                    // alignItems={'center'}
                    gap={"10px"}
                    marginTop={"20px"}
                >
                    {products?.map((element) => (
                        <Box display={"inline-flex"} key={element.id}>
                            <Card
                                boxShadow={"5px 5px 9px #F0EEED"}
                                border={"1px solid #F0EEED"}
                            >
                                <CardHeader>
                                    <Box
                                        display={"inline-flex"}
                                        background={"#F0EEED"}
                                        padding={"10px"}
                                        position={"relative"}
                                    >
                                        <Img
                                            src={element.image}
                                            width={"100%"}
                                        />
                                        <IconButton
                                            _hover={{ background: "#000000" }}
                                            _active={{
                                                transform: "scale(0.8)",
                                            }}
                                            position={"absolute"}
                                            top={"5px"}
                                            right={"5px"}
                                            textColor={"#fff"}
                                            background={"#000000"}
                                            opacity={"0.5"}
                                            icon={<AiOutlineHeart />}
                                        />
                                    </Box>
                                </CardHeader>
                                <CardBody>
                                    <Text>{element.title}</Text>
                                </CardBody>
                                <CardFooter
                                    display={"flex"}
                                    flexDirection={"column"}
                                >
                                    <Text
                                        textColor={"#000000"}
                                        fontSize={"24px"}
                                    >
                                        {element.price} so'm
                                    </Text>
                                    <Button
                                        display={"flex"}
                                        justifyContent={"center"}
                                        alignItems={"center"}
                                        width={"100%"}
                                        padding={"20px"}
                                        textColor={"#fff"}
                                        background={"#000000"}
                                        marginTop={"20px"}
                                        _hover={{ background: "#000000" }}
                                        _active={{ transform: "scale(0.8)" }}
                                    >
                                        BUY
                                    </Button>
                                </CardFooter>
                            </Card>
                        </Box>
                    ))}
                </Box>
            </Box>
        </>
    );
};

export default VewAllProducts;
