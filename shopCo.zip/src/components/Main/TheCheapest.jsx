import {
    Box,
    Button,
    Card,
    CardBody,
    CardFooter,
    CardHeader,
    Heading,
    Img,
    Text,
} from "@chakra-ui/react";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import sortObjToKey from "./sortedArray";
import { setSortProducts } from "../../slice/Product.Slice";

const TheCheapestComponent = () => {
    const { products, toSortedProducts } = useSelector((state) => state.products);
    const dispatch = useDispatch();
    useEffect(() => {
        const cheapestArray = sortObjToKey([...products], "price");
        dispatch(setSortProducts(cheapestArray.slice(0, 4)));
        console.log(cheapestArray)
    }, [products, dispatch]);
    console.log(toSortedProducts)
    return (
        <>
            <Box
                width={"90%"}
                marginX={"auto"}
                display={"flex"}
                marginTop={"40px"}
                // // justifyContent={"start"}
                // alignItems={"start"}
                flexDirection={"column"}
            >
                <Heading textAlign={"center"}>THE CHEAPEST</Heading>
                <Box
                    display={"grid"}
                    // display={'flex'}
                    width={"100%"}
                    // overflowX={'auto'}
                    gridTemplateColumns={"repeat(auto-fit, minmax(200px, 1fr))"}
                    // alignItems={'center'}
                    gap={"10px"}
                    marginTop={"20px"}
                >
                    {toSortedProducts?.map((element) => (
                        <Box display={"inline-flex"} key={element.id}>
                            <Card
                                boxShadow={"5px 5px 9px #F0EEED"}
                                border={"1px solid #F0EEED"}
                            >
                                <CardHeader>
                                    <Box
                                        display={"inline-flex"}
                                        background={"#F0EEED"}
                                        padding={"10px"}
                                    >
                                        <Img
                                            src={element.image}
                                            width={"100%"}
                                        />
                                    </Box>
                                </CardHeader>
                                <CardBody>
                                    <Text>{element.title}</Text>
                                </CardBody>
                                <CardFooter
                                    display={"flex"}
                                    flexDirection={"column"}
                                >
                                    <Text
                                        textColor={"#000000"}
                                        fontSize={"24px"}
                                    >
                                        {element.price} so'm
                                    </Text>
                                    <Button
                                        display={"flex"}
                                        justifyContent={"center"}
                                        alignItems={"center"}
                                        width={"100%"}
                                        padding={"20px"}
                                        textColor={"#fff"}
                                        background={"#000000"}
                                        marginTop={"20px"}
                                        _hover={{ background: "#000000" }}
                                        _active={{ transform: "scale(0.8)" }}
                                    >
                                        BUY
                                    </Button>
                                </CardFooter>
                            </Card>
                        </Box>
                    ))}
                </Box>
            </Box>
        </>
    );
};

export default TheCheapestComponent;
